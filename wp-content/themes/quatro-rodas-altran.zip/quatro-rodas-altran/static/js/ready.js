$(document).ready(function () {
    
    
    $(".dropdown").hover(            
        function() {
            $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideDown("400");
            $(this).toggleClass('open');        
        },
        function() {
            $('.dropdown-menu', this).not('.in .dropdown-menu').stop(true,true).slideUp("400");
            $(this).toggleClass('open');       
        }
    );
    $('#about_us_dropdown').slideDown();
    $('#about_us_dropdown').toggleClass('open');
    

            $.ajax({
                url: "/get/",
                type: "GET",
                dataType: "json",
                data: {
                    acao: 'produto'
                },
                success: function (data) {

                    $(function () {
                        $('#produto').bootstrapTable({
                            data: data
                        });
                    });

                }

            });


            $("a[aria-controls='produtoTab']").click(function() {

                    $.ajax({
                        url: "/get/",
                        type: "GET",
                        dataType: "json",
                        data: {
                            acao: 'produto'
                        },
                        success: function (data) {

                            $(function () {
                                $('#produto').bootstrapTable('destroy').bootstrapTable({
                                    data: data
                                });
                            });

                        }

                    });

                });


            $("a[aria-controls='clienteTab']").click(function() {

                    $.ajax({
                        url: "/get/",
                        type: "GET",
                        dataType: "json",
                        data: {
                            acao: 'cliente'
                        },
                        success: function (data) {

                            $(function () {
                                $('#cliente').bootstrapTable('destroy').bootstrapTable({
                                    data: data
                                });
                            });

                        }

                    });

                });
    
        
        $("a[aria-controls='pedidoTab']").click(function() {

                    $.ajax({
                        url: "/get/",
                        type: "GET",
                        dataType: "json",
                        data: {
                            acao: 'pedido'
                        },
                        success: function (data) {

                            $(function () {
                                $('#pedido').bootstrapTable('destroy').bootstrapTable({
                                    data: data
                                });
                            });

                        }

                    });

                });
    
    



            });